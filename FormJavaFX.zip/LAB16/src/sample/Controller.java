package sample;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Controller {


    public TextField nameField,ageField;
    public RadioButton male,female;
    public CheckBox cb1,cb2,cb3,cb4;
    public Button submit;

    public String getGender(){

        if(male.isDisable())
            return "female";
        else
            return "male";
    }

    public void onButtonClicked() throws IOException {

        System.out.println(nameField.getText());
        System.out.println(nameField.getText() + " is a " + ageField.getText() + " year old " + getGender() );
        System.out.println(nameField.getText() + " plays the follwing sports:-");
        if(cb1.isSelected()){

            System.out.println("Cricket");
        }
        if(cb2.isSelected()){

            System.out.println("Football");
        }
        if(cb3.isSelected()){

            System.out.println("Hockey");
        }
        if(cb4.isSelected()){

            System.out.println("Tennis");
        }

        Stage stage = (Stage) submit.getScene().getWindow();
        stage.close();
    }

    public void maleClicked(){

        female.setDisable(true);
    }

    public void femaleClicked(){

        male.setDisable(true);
    }



}
