module LAB16 {

    requires javafx.fxml;
    requires javafx.controls;
    opens sample;

}