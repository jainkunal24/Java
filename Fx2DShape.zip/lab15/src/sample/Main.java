package sample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.shape.Polygon;
import java.util.*;
public class Main extends Application {

    @Override
    public void start(Stage stage){

        Polygon polygon = new Polygon();
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

            System.out.println("Choose");
            System.out.println("1-Diamond");
            System.out.println("2-Square");
            System.out.println("3-Rectangle");
            System.out.println("4-Pentagon");
            System.out.println("5-Hexagon");
            System.out.println("6-Traingle");

            choice = scanner.nextInt();
            switch(choice){
                case 1:
                    polygon.getPoints().addAll(new Double[]{
                            300.0, 50.0,
                            450.0, 150.0,
                            300.0, 250.0,
                            150.0, 150.0,

                    });
                    polygon.setFill(Color.CHARTREUSE);
                    break;
                case 2:
                    polygon.getPoints().addAll(new Double[]{
                            200.0, 200.0,
                            400.0,200.0,
                            400.0, 400.0,
                            200.0,400.0,

                    });
                    polygon.setFill(Color.VIOLET);
                    break;
                case 3:
                    polygon.getPoints().addAll(new Double[] {

                            100.0,100.0,
                            400.0,100.0,
                            400.0,200.0,
                            100.0,200.0
                    });
                    polygon.setFill(Color.BROWN);
                    break;
                case 4:
                    polygon.getPoints().addAll(new Double[] {

                            300.0,300.0,
                            400.0,400.0,
                            370.0,520.0,
                            230.0,520.0,
                            200.0,400.0,
                    });
                    polygon.setFill(Color.AQUA);
                    break;
                case 5:
                    polygon.getPoints().addAll(new Double[] {

                            200.0,200.0,
                            400.0,200.0,
                            500.0,300.0,
                            400.0,400.0,
                            200.0,400.0,
                            100.0,300.0,
                    });
                    polygon.setFill(Color.RED);
                    break;
                case 6:
                    polygon.getPoints().addAll(new Double[] {

                            300.0,200.0,
                            500.0,500.0,
                            100.0,500.0,
                    });
                    polygon.setFill(Color.GREEN);
            }




        Group root = new Group(polygon);
        Scene scene = new Scene(root, 600, 700);
        stage.setTitle("Drawing a Polygon");
        stage.setScene(scene);
        stage.show();
    }



    public static void main(String[] args){
        launch(args);
    }


}
